export function redirectSystemPath({
  path,
  initial,
}: { path: string; initial: boolean }) {
  return '/';
}
