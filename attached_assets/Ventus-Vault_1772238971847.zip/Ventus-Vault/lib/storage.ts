import AsyncStorage from "@react-native-async-storage/async-storage";

const KEYS = {
  USER: "@ventusvault_user",
  TRANSACTIONS: "@ventusvault_transactions",
  REFERRALS: "@ventusvault_referrals",
  REWARDS: "@ventusvault_rewards",
  BANKS: "@ventusvault_banks",
};

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  tier: "basic" | "vip" | "investor";
  walletBalance: number;
  referralCode: string;
  referralCount: number;
  referralEarnings: number;
  totalTrades: number;
  joinedAt: string;
}

export interface Transaction {
  id: string;
  type: "gift_card" | "crypto_buy" | "crypto_sell" | "payout" | "airtime" | "bill" | "reward" | "referral";
  title: string;
  amount: number;
  status: "completed" | "pending" | "failed";
  timestamp: string;
  details?: string;
}

export interface RewardCard {
  id: string;
  type: "cashback" | "bonus" | "credit" | "multiplier";
  value: number;
  label: string;
  claimed: boolean;
  claimedAt?: string;
}

export interface BankAccount {
  id: string;
  bankName: string;
  accountNumber: string;
  accountName: string;
  isDefault: boolean;
}

const defaultUser: UserProfile = {
  id: "usr_001",
  name: "Victor Adeyemi",
  email: "victor@ventusvault.com",
  phone: "+234 812 345 6789",
  tier: "vip",
  walletBalance: 485750.0,
  referralCode: "VENTUS-VIC2025",
  referralCount: 14,
  referralEarnings: 32500,
  totalTrades: 87,
  joinedAt: "2025-01-15T10:00:00Z",
};

const defaultTransactions: Transaction[] = [
  { id: "tx_001", type: "gift_card", title: "iTunes $100 Sold", amount: 85000, status: "completed", timestamp: "2026-02-24T09:30:00Z", details: "iTunes Gift Card" },
  { id: "tx_002", type: "crypto_sell", title: "BTC Sold 0.005", amount: 125400, status: "completed", timestamp: "2026-02-24T08:15:00Z", details: "Bitcoin" },
  { id: "tx_003", type: "payout", title: "Bank Payout", amount: -200000, status: "completed", timestamp: "2026-02-23T16:45:00Z", details: "Access Bank" },
  { id: "tx_004", type: "airtime", title: "MTN Airtime", amount: -2000, status: "completed", timestamp: "2026-02-23T14:20:00Z", details: "MTN 2GB Data" },
  { id: "tx_005", type: "reward", title: "Spin Reward", amount: 5000, status: "completed", timestamp: "2026-02-23T12:00:00Z", details: "Daily Spin Bonus" },
  { id: "tx_006", type: "referral", title: "Referral Bonus", amount: 2500, status: "completed", timestamp: "2026-02-22T18:30:00Z", details: "New user signed up" },
  { id: "tx_007", type: "crypto_buy", title: "ETH Bought 0.1", amount: -48500, status: "completed", timestamp: "2026-02-22T11:00:00Z", details: "Ethereum" },
  { id: "tx_008", type: "gift_card", title: "Amazon $50 Sold", amount: 42000, status: "pending", timestamp: "2026-02-22T09:45:00Z", details: "Amazon Gift Card" },
];

const defaultBanks: BankAccount[] = [
  { id: "bnk_001", bankName: "Access Bank", accountNumber: "0123456789", accountName: "Victor Adeyemi", isDefault: true },
  { id: "bnk_002", bankName: "GTBank", accountNumber: "0987654321", accountName: "Victor Adeyemi", isDefault: false },
];

export async function getUser(): Promise<UserProfile> {
  try {
    const data = await AsyncStorage.getItem(KEYS.USER);
    if (data) return JSON.parse(data);
    await AsyncStorage.setItem(KEYS.USER, JSON.stringify(defaultUser));
    return defaultUser;
  } catch {
    return defaultUser;
  }
}

export async function updateUser(updates: Partial<UserProfile>): Promise<UserProfile> {
  const user = await getUser();
  const updated = { ...user, ...updates };
  await AsyncStorage.setItem(KEYS.USER, JSON.stringify(updated));
  return updated;
}

export async function getTransactions(): Promise<Transaction[]> {
  try {
    const data = await AsyncStorage.getItem(KEYS.TRANSACTIONS);
    if (data) return JSON.parse(data);
    await AsyncStorage.setItem(KEYS.TRANSACTIONS, JSON.stringify(defaultTransactions));
    return defaultTransactions;
  } catch {
    return defaultTransactions;
  }
}

export async function addTransaction(tx: Transaction): Promise<void> {
  const txns = await getTransactions();
  txns.unshift(tx);
  await AsyncStorage.setItem(KEYS.TRANSACTIONS, JSON.stringify(txns));
}

export async function getRewards(): Promise<RewardCard[]> {
  try {
    const data = await AsyncStorage.getItem(KEYS.REWARDS);
    if (data) return JSON.parse(data);
    return [];
  } catch {
    return [];
  }
}

export async function addReward(reward: RewardCard): Promise<void> {
  const rewards = await getRewards();
  rewards.unshift(reward);
  await AsyncStorage.setItem(KEYS.REWARDS, JSON.stringify(rewards));
}

export async function getBanks(): Promise<BankAccount[]> {
  try {
    const data = await AsyncStorage.getItem(KEYS.BANKS);
    if (data) return JSON.parse(data);
    await AsyncStorage.setItem(KEYS.BANKS, JSON.stringify(defaultBanks));
    return defaultBanks;
  } catch {
    return defaultBanks;
  }
}
