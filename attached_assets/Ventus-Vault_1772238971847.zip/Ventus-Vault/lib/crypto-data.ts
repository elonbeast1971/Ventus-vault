export interface CryptoAsset {
  id: string;
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  icon: string;
  color: string;
  ngnRate: number;
}

export const cryptoAssets: CryptoAsset[] = [
  { id: "btc", symbol: "BTC", name: "Bitcoin", price: 96842.5, change24h: 2.34, icon: "logo-bitcoin", color: "#F7931A", ngnRate: 1580 },
  { id: "eth", symbol: "ETH", name: "Ethereum", price: 3245.8, change24h: -1.12, icon: "diamond", color: "#627EEA", ngnRate: 1575 },
  { id: "usdt", symbol: "USDT", name: "Tether", price: 1.0, change24h: 0.01, icon: "swap-horizontal", color: "#26A17B", ngnRate: 1570 },
  { id: "sol", symbol: "SOL", name: "Solana", price: 198.45, change24h: 5.67, icon: "flash", color: "#9945FF", ngnRate: 1575 },
];

export interface GiftCard {
  id: string;
  name: string;
  icon: string;
  rate: number;
  color: string;
  minAmount: number;
  maxAmount: number;
}

export const giftCards: GiftCard[] = [
  { id: "itunes", name: "iTunes", icon: "musical-notes", rate: 850, color: "#FC3C44", minAmount: 25, maxAmount: 500 },
  { id: "amazon", name: "Amazon", icon: "cart", rate: 840, color: "#FF9900", minAmount: 25, maxAmount: 1000 },
  { id: "steam", name: "Steam", icon: "game-controller", rate: 800, color: "#171A21", minAmount: 20, maxAmount: 200 },
  { id: "google", name: "Google Play", icon: "logo-google", rate: 780, color: "#34A853", minAmount: 10, maxAmount: 500 },
  { id: "ebay", name: "eBay", icon: "pricetag", rate: 750, color: "#E53238", minAmount: 25, maxAmount: 500 },
  { id: "walmart", name: "Walmart", icon: "storefront", rate: 760, color: "#0071CE", minAmount: 25, maxAmount: 500 },
  { id: "nike", name: "Nike", icon: "fitness", rate: 770, color: "#111111", minAmount: 25, maxAmount: 300 },
  { id: "sephora", name: "Sephora", icon: "sparkles", rate: 780, color: "#000000", minAmount: 25, maxAmount: 250 },
];

export const rewardTypes = [
  { type: "cashback" as const, label: "2% Cashback", value: 2, color: "#D4A843" },
  { type: "bonus" as const, label: "N5,000 Bonus", value: 5000, color: "#00C853" },
  { type: "credit" as const, label: "N2,500 Credit", value: 2500, color: "#627EEA" },
  { type: "multiplier" as const, label: "2x Next Trade", value: 2, color: "#9945FF" },
  { type: "cashback" as const, label: "5% Cashback", value: 5, color: "#F7931A" },
  { type: "bonus" as const, label: "N1,000 Bonus", value: 1000, color: "#26A17B" },
  { type: "credit" as const, label: "N500 Credit", value: 500, color: "#FC3C44" },
  { type: "bonus" as const, label: "N10,000 Bonus", value: 10000, color: "#FF9900" },
];

export const billCategories = [
  { id: "airtime", name: "Airtime", icon: "call", color: "#00C853" },
  { id: "data", name: "Data", icon: "wifi", color: "#627EEA" },
  { id: "electricity", name: "Electricity", icon: "flash", color: "#F7931A" },
  { id: "cable", name: "Cable TV", icon: "tv", color: "#FC3C44" },
  { id: "internet", name: "Internet", icon: "globe", color: "#9945FF" },
  { id: "water", name: "Water", icon: "water", color: "#26A17B" },
];

export const networks = [
  { id: "mtn", name: "MTN", color: "#FFCC00" },
  { id: "airtel", name: "Airtel", color: "#FF0000" },
  { id: "glo", name: "Glo", color: "#00A651" },
  { id: "9mobile", name: "9mobile", color: "#006E3B" },
];
